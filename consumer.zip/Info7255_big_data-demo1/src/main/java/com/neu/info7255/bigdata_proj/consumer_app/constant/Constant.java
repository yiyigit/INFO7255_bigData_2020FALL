package com.neu.info7255.bigdata_proj.consumer_app.constant;

public class Constant {

    public static String PLAN = "plan";

    public static String TYPE = "_doc";

    public static String ES_POST = "index";

    public static String ES_DELETE = "delete";

}